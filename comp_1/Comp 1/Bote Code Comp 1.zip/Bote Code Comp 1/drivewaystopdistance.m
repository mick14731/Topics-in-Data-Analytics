%This script calculates the closest stop for each driveway

%Loads the driveway data
load('driveway.mat')
load('stops.mat')
distArray=[];
for d = 1:length(driveways)
    %Obtain driveway coordinates.
    driveway=driveways(d,:);
    c=bsxfun(@minus,stops,driveway);
    %Finds the min. distance stop
    [out,idx]=min(hypot(c(:,1),c(:,2)));
    closeststop=stops(idx,:);
    %Calculates distance from coordinates
    dist=lldistkm(closeststop,driveway);
    distArray=[distArray;[driveway,dist]];
end

%Calculates basic statistics
meandist=mean(distArray(3));
maxdist=max(distArray(3));
mindist=min(distArray(3));
modedist=mode(distArray(3));
