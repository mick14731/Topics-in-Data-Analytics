%This script calculates the the closest route for each driveway
clear all

%Imports all bus routes and driveways
load ('busroutes.mat')
load('driveway.mat')
routeCell={route01,route02,route03,route04, route06,route07,route08,route10,route11, route12, route14, route15, route16, route17A, route18, route20, route501, route502, route601, route602, route701, route702, route801, route802,routeCOV};
routeCell2={001,002,003,004,006,007,008,100,011,012,014,015,016,017,018,020,501,502,601,602,701,702,801,802,000};

%Contains the closest route for each driveway
closestRouteArray=[];

for d = 1:length(driveways)
    %Obtain driveway coordinates.
    driveway=driveways(d,:);
    %Allows for comparison for all routes for each driveway
    routeDistForDriveway=[];
    for r = 1:length(routeCell)
        currentRoute=routeCell{r};
        %Finds the route that has the shortest distance to the driveway
        currentRoute=[currentRoute(:,2),currentRoute(:,1)];
        c=bsxfun(@minus,currentRoute,driveway);
        [out,idx]=min(norm(c(:,1)-c(:,2)));
        closestR=currentRoute(idx,:);
        dist=lldistkm(closestR,driveway);
        routeDistForDriveway=[routeDistForDriveway,dist];
    end
    [minVal,minIndex]=min(routeDistForDriveway);
    closestRoute=routeCell2{minIndex};
    %Appends to an output array
    closestRouteArray=[closestRouteArray;[driveway,minVal,closestRoute]];
end